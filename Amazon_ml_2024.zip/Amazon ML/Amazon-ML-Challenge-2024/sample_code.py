import os
import random
import pandas as pd

def predictor(image_link, category_id, entity_name):
    return "" if random.random() > 0.5 else "10 inch"

if __name__ == "__main__":
    # Use absolute path to avoid confusion
    DATASET_FOLDER = 'C:/Users/DELL/OneDrive/Desktop/Amazon ML/Amazon-ML-Challenge-2024/dataset/'
    
    # Ensure the dataset folder exists
    if not os.path.exists(DATASET_FOLDER):
        print(f"Directory not found: {DATASET_FOLDER}")
    else:
        print(f"Directory found: {DATASET_FOLDER}")

    # Load the test dataset
    test_file_path = os.path.join(DATASET_FOLDER, 'test.csv')
    if os.path.exists(test_file_path):
        test = pd.read_csv(test_file_path)
        test['prediction'] = test.apply(
            lambda row: predictor(row['image_link'], row['group_id'], row['entity_name']), axis=1)
    
        # Save the output
        output_filename = os.path.join(DATASET_FOLDER, 'test_out.csv')
        test[['index', 'prediction']].to_csv(output_filename, index=False)
        print(f"Predictions saved to {output_filename}")
    else:
        print(f"File not found: {test_file_path}")
